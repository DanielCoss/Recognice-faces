# Face Detection with OpenCV

The original link to the model file

https://github.com/opencv/opencv_3rdparty/raw/dnn_samples_face_detector_20170830/res10_300x300_ssd_iter_140000.caffemodel

https://github.com/opencv/opencv_extra/blob/master/testdata/dnn/opencv_face_detector.pbtxt
